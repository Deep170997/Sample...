﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Runtime.Serialization;
using System.Web;

namespace MyFinanceMgmtProject.Models
{
    [MetadataType(typeof(MetaDataForPayementPlan))]
    public partial class PayementPlan
    {
    }
    [DataContract]
    public class MetaDataForPayementPlan
    {
        [DataMember]
        public int id { get; set; }
        [DataMember]
        public int Duration { get; set; }
        [DataMember]
        public string data { get; set; }
    }


}