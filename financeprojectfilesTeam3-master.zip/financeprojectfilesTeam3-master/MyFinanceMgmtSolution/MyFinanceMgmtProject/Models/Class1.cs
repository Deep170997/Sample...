﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Runtime.Serialization;
using System.Web;

namespace MyFinanceMgmtProject.Models
{
    [MetadataType(typeof(MetaDataForAccount))]
    public partial class Account
    {
    }
    [DataContract]
     public class MetaDataForAccount
    {
        [DataMember]
        public int id { get; set; }
        [DataMember]
        public int PurchaseId { get; set; }
        [DataMember]
        public Nullable<System.DateTime> Date { get; set; }
        [DataMember]
        public int Paid { get; set; }
        [DataMember]
        public int Balence { get; set; }


    }
}