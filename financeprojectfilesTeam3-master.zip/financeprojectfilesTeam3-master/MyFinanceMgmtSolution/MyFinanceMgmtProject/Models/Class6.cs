﻿using System;
using System.CodeDom;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Runtime.Serialization;
using System.Web;

namespace MyFinanceMgmtProject.Models
{
    [MetadataType(typeof(MetaDataForCustomerPurchasal))]
    public partial class CustomerPurchasal
    {
    }
    [DataContract]
    public class MetaDataForCustomerPurchasal
    {
        [DataMember]
        public int id { get; set; }
        [DataMember]
        public int CardNumber { get; set; }
        [DataMember]
        public Nullable<int> PayementPlan { get; set; }
        [DataMember]
        public Nullable<int> ProductId { get; set; }
        [DataMember]
        public Nullable<System.DateTime> PuchaseDate { get; set; }
        [DataMember]
        public Nullable<int> BillAmount { get; set; }
        [DataMember]
        public Nullable<int> ProcessingFee { get; set; }
        [DataMember]
        public Nullable<int> NetAmount { get; set; }
        [DataMember]
        public Nullable<int> DownPayement { get; set; }
    }
}