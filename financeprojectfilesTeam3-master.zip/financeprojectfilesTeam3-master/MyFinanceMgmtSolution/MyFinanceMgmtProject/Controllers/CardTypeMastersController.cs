﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Cors;
using System.Web.Http.Description;
using MyFinanceMgmtProject.Models;

namespace MyFinanceMgmtProject.Controllers
{
    [EnableCors(origins:"http://localhost:4200",headers:"*", methods:"*")]
    public class CardTypeMastersController : ApiController
    {
        private FinanceManagementSystemEntities db = new FinanceManagementSystemEntities();

        // GET: api/CardTypeMasters
        public IQueryable<CustomerMaster> GetCardTypeMasters()
        {
            //return db.CardTypeMasters;
            return db.CustomerMasters;
        }

        // GET: api/CardTypeMasters/5
        [ResponseType(typeof(CardTypeMaster))]
        public IHttpActionResult GetCardTypeMaster(int id)
        {
            CardTypeMaster cardTypeMaster = db.CardTypeMasters.Find(id);
            if (cardTypeMaster == null)
            {
                return NotFound();
            }

            return Ok(cardTypeMaster);
        }

        // PUT: api/CardTypeMasters/5
        [ResponseType(typeof(void))]
        public IHttpActionResult PutCardTypeMaster(int id, CardTypeMaster cardTypeMaster)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != cardTypeMaster.id)
            {
                return BadRequest();
            }

            db.Entry(cardTypeMaster).State = EntityState.Modified;

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!CardTypeMasterExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        // POST: api/CardTypeMasters
        [ResponseType(typeof(CardTypeMaster))]
        public IHttpActionResult PostCardTypeMaster(CardTypeMaster cardTypeMaster)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            db.CardTypeMasters.Add(cardTypeMaster);
            db.SaveChanges();

            return CreatedAtRoute("DefaultApi", new { id = cardTypeMaster.id }, cardTypeMaster);
        }

        // DELETE: api/CardTypeMasters/5
        [ResponseType(typeof(CardTypeMaster))]
        public IHttpActionResult DeleteCardTypeMaster(int id)
        {
            CardTypeMaster cardTypeMaster = db.CardTypeMasters.Find(id);
            if (cardTypeMaster == null)
            {
                return NotFound();
            }

            db.CardTypeMasters.Remove(cardTypeMaster);
            db.SaveChanges();

            return Ok(cardTypeMaster);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool CardTypeMasterExists(int id)
        {
            return db.CardTypeMasters.Count(e => e.id == id) > 0;
        }
    }
}