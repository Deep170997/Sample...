﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Runtime.Serialization;
using System.Web;

namespace MyFinanceMgmtProject.Models
{
    [MetadataType(typeof(MetaDataTypeForPayementSchedule))]
    public partial class PayementSchedule
    {
    }
    [DataContract]
    public class MetaDataTypeForPayementSchedule
    {
        [DataMember]
        public int id { get; set; }
        [DataMember]
        public int PurchasalId { get; set; }
        [DataMember]
        public System.DateTime payementDate { get; set; }
        [DataMember]
        public int Amount { get; set; }
        [DataMember]
        public byte Paid { get; set; }
    }
}