﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using MyFinanceMgmtProject.Models;
using System.Web.Http.Cors;

namespace MyFinanceMgmtProject.Controllers
{
    [EnableCors(origins: "http://localhost:4200", headers: "*", methods: "*")]
    public class ProductListsController : ApiController
    {
        private FinanceManagementSystemEntities db = new FinanceManagementSystemEntities();

        // GET: api/ProductLists
        public IQueryable<ProductList> GetProductLists()
        {
            return db.ProductLists;
        }

        // GET: api/ProductLists/5
        [ResponseType(typeof(ProductList))]
        public IHttpActionResult GetProductList(int id)
        {
            ProductList productList = db.ProductLists.Find(id);
            if (productList == null)
            {
                return NotFound();
            }

            return Ok(productList);
        }

        // PUT: api/ProductLists/5
        [ResponseType(typeof(void))]
        public IHttpActionResult PutProductList(int id, ProductList productList)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != productList.id)
            {
                return BadRequest();
            }

            db.Entry(productList).State = EntityState.Modified;

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!ProductListExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        // POST: api/ProductLists
        [ResponseType(typeof(ProductList))]
        public IHttpActionResult PostProductList(ProductList productList)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            db.ProductLists.Add(productList);
            db.SaveChanges();

            return CreatedAtRoute("DefaultApi", new { id = productList.id }, productList);
        }

        // DELETE: api/ProductLists/5
        [ResponseType(typeof(ProductList))]
        public IHttpActionResult DeleteProductList(int id)
        {
            ProductList productList = db.ProductLists.Find(id);
            if (productList == null)
            {
                return NotFound();
            }

            db.ProductLists.Remove(productList);
            db.SaveChanges();

            return Ok(productList);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool ProductListExists(int id)
        {
            return db.ProductLists.Count(e => e.id == id) > 0;
        }
    }
}