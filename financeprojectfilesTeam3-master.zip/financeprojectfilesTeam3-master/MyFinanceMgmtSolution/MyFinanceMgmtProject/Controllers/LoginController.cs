﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using MyFinanceMgmtProject.Models;
using System.Web.Http.Cors;

namespace MyFinanceMgmtProject.Controllers
{
    [EnableCors(origins: "http://localhost:4200", headers: "*", methods: "*")]
    public class LoginController : ApiController
    {
        private FinanceManagementSystemEntities db = new FinanceManagementSystemEntities();

        // GET: api/Login
        public IQueryable<CustomerMaster> GetCustomerMasters()
        {
            return db.CustomerMasters;
        }
        // POST: api/Login
        [HttpGet]
        [ResponseType(typeof(CustomerMaster))]
        public sp_Login_Result sp_Login_Result ([FromUri] string uname, string password )
        {
            sp_Login_Result cust = null;
            try {
                cust = db.sp_Login(uname, password).First();

            }
            catch (Exception e )
            {
                return null;
            }

            return cust;

        }
        [HttpGet]
        public IQueryable<CardDetail> CarDetails ([FromUri] int id,int cust_id)
        {
            return db.CardDetails.Where(c => c.CustId == cust_id);

            //return cards;
        }

        public IQueryable<PayementPlan> Payementplan([FromUri] string paymentplan)
        {
            return db.PayementPlans;
        }
    }
}