﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Runtime.Serialization;
using System.Web;

namespace MyFinanceMgmtProject.Models
{
    [MetadataType(typeof(MetaDataForProductList))]
    public partial class ProductList
    {
    }
    [DataContract]
    public class MetaDataForProductList
    {
        [DataMember]
        public int id { get; set; }
        [DataMember]
        public Nullable<int> TypeId { get; set; }
        [DataMember]
        public string Name { get; set; }
        [DataMember]
        public int Stock { get; set; }
        [DataMember]
        public string UnitPrice { get; set; }
        [DataMember]
        public string images1 { get; set; }
        [DataMember]
        public string proddesc { get; set; }

    }
}