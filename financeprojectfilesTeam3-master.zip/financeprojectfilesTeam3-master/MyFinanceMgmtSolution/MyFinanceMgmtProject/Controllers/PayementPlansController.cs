﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using MyFinanceMgmtProject.Models;
using System.Web.Http.Cors;

namespace MyFinanceMgmtProject.Controllers
{
    [EnableCors(origins: "http://localhost:4200", headers: "*", methods: "*")]
    public class PayementPlansController : ApiController
    {
        private FinanceManagementSystemEntities db = new FinanceManagementSystemEntities();

        // GET: api/PayementPlans
        public IQueryable<PayementPlan> GetPayementPlans()
        {
            return db.PayementPlans;
        }

        // GET: api/PayementPlans/5
        [ResponseType(typeof(PayementPlan))]
        public IHttpActionResult GetPayementPlan(int id)
        {
            PayementPlan payementPlan = db.PayementPlans.Find(id);
            if (payementPlan == null)
            {
                return NotFound();
            }

            return Ok(payementPlan);
        }

        // PUT: api/PayementPlans/5
        [ResponseType(typeof(void))]
        public IHttpActionResult PutPayementPlan(int id, PayementPlan payementPlan)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != payementPlan.id)
            {
                return BadRequest();
            }

            db.Entry(payementPlan).State = EntityState.Modified;

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!PayementPlanExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        // POST: api/PayementPlans
        [ResponseType(typeof(PayementPlan))]
        public IHttpActionResult PostPayementPlan(PayementPlan payementPlan)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            db.PayementPlans.Add(payementPlan);
            db.SaveChanges();

            return CreatedAtRoute("DefaultApi", new { id = payementPlan.id }, payementPlan);
        }

        // DELETE: api/PayementPlans/5
        [ResponseType(typeof(PayementPlan))]
        public IHttpActionResult DeletePayementPlan(int id)
        {
            PayementPlan payementPlan = db.PayementPlans.Find(id);
            if (payementPlan == null)
            {
                return NotFound();
            }

            db.PayementPlans.Remove(payementPlan);
            db.SaveChanges();

            return Ok(payementPlan);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool PayementPlanExists(int id)
        {
            return db.PayementPlans.Count(e => e.id == id) > 0;
        }
    }
}